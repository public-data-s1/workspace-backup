n = int(input())

for _ in range(0, n):
    a = input()
    b = input()
    la = len(a)
    lb = len(b)
    a = a+'0'
    pos = 0
    for i in range(0, lb):
        if (a[pos] == b[i]) and pos < la:
            pos += 1
        elif b[i - 1] != b[i] or i == 0:
            pos = -1
            break
    print("YES" if pos == la else "NO")
