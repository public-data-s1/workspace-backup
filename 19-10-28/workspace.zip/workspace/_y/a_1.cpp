#include <bits/stdc++.h>
using namespace std;
long long m, n, w[1000005], sum[1000005], sec[1000005], t[1000005];
struct node
{
    int id, t;
} a[1000005];
bool cmp(node x, node y)
{
    return x.id < y.id;
}
bool cmp2(node x, node y)
{
    return x.t < y.t;
}
int main()
{
    freopen("s.in", "r", stdin);
    freopen("2.out", "w", stdout);
    cin >> m >> n;
    for (int i = 1; i <= m; i++)
        scanf("%lld", &w[i]);
    for (int i = 1; i <= m; i++)
        sum[i] = sum[i - 1] + w[i];
    for (int i = 1; i <= n; i++)
        scanf("%lld", &t[i]);
    for (int i = 1; i <= n; i++)
    {
        int ans = 0;
        int pos = upper_bound(sum + 1, sum + m + 1, t[i]) - sum;
        if (pos == n + 1)
        {
            printf("%d\n", n);
            continue;
        }
        pos--;
        ans += pos;
        t[i] -= sum[pos];
        for (int j = pos + 1; j <= m; j++)
        {
            if (t[i] >= w[j])
            {
                t[i] -= w[j];
                ans++;
            }
            if (!t[i])
                break;
        }
        printf("%d\n", ans);
    }

    return 0;
}