io::read(n);
        io::read(x);
        cout << C(n, x) << endl;
    