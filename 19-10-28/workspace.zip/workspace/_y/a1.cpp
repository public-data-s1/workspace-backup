
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int help(vector<vector<int>> matrix, int i, int j);
bool isJoint(vector<vector<int>> matrix, int i, int j);
int main()
{
    int n, m, k;
    cin >> n >> m >> k;
    int u, v;
    vector<vector<int>> matrix(n);
    for (int i = 0; i < k; i++)
    {
        cin >> u >> v;
        matrix[u - 1].push_back(v);
    }

    int cnt = 0;
    bool tag;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                continue; //遇到与自己配对的直接跳过
            tag = false;
            if (matrix[i].size() == 0 || matrix[j].size() == 0)
                cnt++;
            else
            {
                for (auto it : matrix[i])
                    if (find(matrix[j].begin(), matrix[j].end(), it) != matrix[j].end())
                    {
                        tag = true;
                        break;
                    }
                if (!tag)
                    cnt += help(matrix, i, j);
            }
        }
    }
    cout << cnt / n << endl; //去重
    return 0;
}
int help(vector<vector<int>> matrix, int i, int j)
{ //
    for (int k = 0; k < matrix.size(); k++)
    {
        if (k == i || k == j)
            continue;
        if (isJoint(matrix, i, k) && isJoint(matrix, j, k))
            return 0; //若寻求到了第三人帮助，不需
                      // 额外添加翻译机
    }
    return 1; ////若没寻求到第三人帮助，需额外添加翻译机： cnt++
}

bool isJoint(vector<vector<int>> matrix, int i, int j)
{ //判断两人是否具有语言交集
    if (matrix[i].size() == 0 || matrix[j].size() == 0)
        return false;
    vector<int> im(matrix[i]);
    vector<int> jm(matrix[j]);
    sort(im.begin(), im.end()); // 排序为了更容易比较两个vector（降低时间复杂度）
    sort(jm.begin(), jm.end());
    int idx = 0, jdx = 0;
    while (idx < matrix[i].size() && jdx < matrix[j].size())
    { //时间复杂度O（n+m）
        if (im[idx] > jm[jdx])
            jdx++;
        else if (im[idx] < jm[jdx])
            idx++;
        else
            return true; //两人有共同语言，结束返回
    }
    return false; //两人没有语言交集
}