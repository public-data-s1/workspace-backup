#include "bits/stdc++.h"
using namespace std;
mt19937 mt(19260817);
int main()
{
    freopen("s.in", "w", stdout);
    puts("10010 10010");
    for (int i = 1; i <= 10010; i++)
    {
        printf("%d ", i);
    }
    puts("");
    for (int i = 1; i <= 10010; i++)
    {
        printf("%d ", mt() % 65536);
    }
}