#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4.1,sse4.2,avx,avx2,popcnt,tune=native")

#include "bits/stdc++.h"
#define _mem(x) memset((x), 0, sizeof((x)))
#define _il __attribute__((always_inline))
using namespace std;
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
#if __cplusplus > 201403L // Implement P0001R1 - C++17 removal of register storage class specifier
#define _r
#else
#define _r register
#endif
#define ri _r int
#define rl _r ll
#define _c_ const
namespace _c
{
_c_ double pi = acos(-1.0); // PI
namespace min
{
_c_ int i8 = -128;
_c_ int i16 = -32768;
_c_ int i = -2147483647 - 1;
_c_ ll l = -9223372036854775807LL - 1;
} // namespace min
namespace max
{
_c_ int i8 = 127;
_c_ int i16 = 32767;
_c_ int i = 2147483647;
_c_ ll l = 9223372036854775807LL;
} // namespace max
} // namespace _c
namespace _f
{
template <typename T> // return gcd
inline _c_ T gcd(T m, T n)
{
    while (n != 0)
    {
        T t = m % n;
        m = n;
        n = t;
    }
    return m;
}
template <typename T> // return max
inline _c_ T max(_c_ T &a, _c_ T &b)
{
    return a > b ? a : b;
}
template <typename T> //return min
inline _c_ T min(_c_ T &a, _c_ T &b)
{
    return a < b ? a : b;
}
template <typename T> // return abs
inline _c_ T abs(_c_ T &a)
{
    return a > 0 ? a : -a;
}
template <typename T> // quick pow - calculate a ^ b
inline T pow(T a, T b)
{
    T res = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            res = res * a;
        }
        a = a * a;
        b >>= 1;
    }
    return res;
}
template <typename T> // quick pow - with module
inline T pow(T a, T b, _c_ T &mod)
{
    a %= mod;
    T res = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            res = res * a % mod;
        }
        a = a * a % mod;
        b >>= 1;
    }
    return res % mod;
}
} // namespace _f
namespace io
{
template <typename T>  // read int
inline void read(T &t) // or long long
{
    _r T res = 0, neg = 1;
    char c = getchar();
    for (; !isdigit(c); c = getchar())
    {
        if (c == '-')
        {
            neg = -1;
        }
    }
    for (; isdigit(c); c = getchar())
    {
        res = res * 10 + c - '0';
    }
    t = res * neg;
}
inline int in() // read int
{
    ri T;
    read(T);
    return T;
}
inline ll in_ll() // read long long
{
    rl T;
    read(T);
    return T;
}
} // namespace io
#undef _c_

int N, M, K, x, y;

int main()
{
    io::read(N), io::read(M), io::read(K);
    for (int i = 0; i < K; i++)
    {
        io::read(x), io::read(y);
        if (x <= 5 || x > N - 5 || y <= 5 || y > M - 5)
        {
            puts("YES");
            return 0;
        }
    }
    puts("NO");
    return 0;
}