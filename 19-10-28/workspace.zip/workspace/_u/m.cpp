#include <bits/stdc++.h>
using namespace std;
long long a, b, ans;
bool flag;
int main()
{
    cin >> a >> b;
    long long delta = 4 * b - a * a;
    if (delta == 0)
    {
        puts("inf");
        return 0;
    }
    if (delta < 0)
        flag = 1;
    delta = abs(delta);
    if (a & 1)
    {
        for (int i = 1; i <= sqrt(delta); i++)
        {
            if (delta % i != 0)
                continue;
            long long xx = delta / i;
            if ((((xx + i) / 2) & 1) && flag && ((xx + i) / 2) >= a)
                ans++;
            if (!flag && (((xx - i) / 2) & 1) && ((xx - i) / 2) >= a)
                ans++;
        }
        cout << ans;
        return 0;
    }
    for (int i = 2; i <= sqrt(delta); i += 2)
    {
        if (delta % i != 0)
            continue;
        long long xx = delta / i;
        if (xx & 1)
            continue;
        if (!(((xx + i) / 2) & 1) && !(((xx - i) / 2) & 1))
        {
            if (((xx + i) / 2) >= a && flag)
            {
                //cout<<i<<' '<<xx<<endl;
                ans++;
            }
            if (((xx - i) / 2) >= a && !flag)
            {
                //cout<<i<<' '<<xx<<endl;
                ans++;
            }
        }
    }
    cout << ans;
    return 0;
}