#include "bits/stdc++.h"
using namespace std;
int main()
{
    freopen("test.out", "w", stdout);
    srand(time(NULL));
    cout << 1000000 << endl;
    for (int i = 1; i <= 1000000; i++)
    {
        printf("%d %d\n", rand() % 3 + 1, rand() * rand() % 100000000);
    }
    return 0;
}