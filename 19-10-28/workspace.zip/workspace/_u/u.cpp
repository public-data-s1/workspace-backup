#pragma GCC diagnostic error "-std=c++11"
#pragma GCC target("avx")
#pragma GCC optimize(3)
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-fstrict-overflow")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-skip-blocks")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")

#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4.1,sse4.2,avx,avx2,popcnt,tune=native")

#include "bits/stdc++.h"
#define mem(x) memset((x), 0, sizeof((x)))
#define il __attribute__((always_inline))
using namespace std;
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
#if __cplusplus > 201403L
#define r
#else
#define r register
#endif
#define ri r int
#define rl r ll
#define c const
namespace _c
{
c double pi = acos(-1.0); // PI
namespace min
{
c int i8 = -128;
c int i16 = -32768;
c int i = -2147483647 - 1;
c ll l = -9223372036854775807LL - 1;
} // namespace min
namespace max
{
c int i8 = 127;
c int i16 = 32767;
c int i = 2147483647;
c ll l = 9223372036854775807LL;
} // namespace max
} // namespace _c
namespace _f
{
template <typename T> // return gcd
inline c T gcd(T m, T n)
{
    while (n != 0)
    {
        T t = m % n;
        m = n;
        n = t;
    }
    return m;
}
template <typename T>
inline c T max(c T &a, c T &b)
{
    return a > b ? a : b;
}
template <typename T>
inline c T min(c T &a, c T &b)
{
    return a < b ? a : b;
}
template <typename T>
inline c T abs(c T &a)
{
    return a > 0 ? a : -a;
}
template <typename T>
inline T pow(T a, T b)
{
    T res = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            res = res * a;
        }
        a = a * a;
        b >>= 1;
    }
    return res;
}
template <typename T>
inline T pow(T a, T b, c T &m)
{
    a %= m;
    T res = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            res = res * a % m;
        }
        a = a * a % m;
        b >>= 1;
    }
    return res % m;
}
} // namespace _f
namespace io
{
template <typename T>
inline void read(T &t)
{
    r T res = 0, neg = 1;
    char g = getchar();
    for (; !isdigit(g); g = getchar())
    {
        if (g == '-')
        {
            neg = -1;
        }
    }
    for (; isdigit(g); g = getchar())
    {
        res = res * 10 + g - '0';
    }
    t = res * neg;
}
inline int in()
{
    ri T;
    read(T);
    return T;
}
inline ll in_ll()
{
    rl T;
    read(T);
    return T;
}
} // namespace io
#undef c
#undef r

struct node
{
    int c7, c4, up, down, left, right;
    bool rev;
} tree[4000006];
char s[1000006];

void maintain(int k)
{
    tree[k].c7 = tree[k << 1].c7 + tree[k << 1 | 1].c7;
    tree[k].c4 = tree[k << 1].c4 + tree[k << 1 | 1].c4;
    tree[k].up = _f::max(tree[k << 1].up + tree[k << 1 | 1].c7, tree[k << 1].c4 + tree[k << 1 | 1].up);
    tree[k].down = _f::max(tree[k << 1].down + tree[k << 1 | 1].c4, tree[k << 1].c7 + tree[k << 1 | 1].down);
}
void build(int l, int r, int k)
{
    tree[k].left = l;
    tree[k].right = r;
    tree[k].rev = false;
    if (l == r)
    {
        tree[k].c7 = tree[k].c4 = 0;
        tree[k].up = tree[k].down = 1;
        if (s[l] == '7')
        {
            tree[k].c7 = 1;
        }
        else
        {
            tree[k].c4 = 1;
        }
        return;
    }
    int mid = (tree[k].left + tree[k].right) >> 1;
    build(l, mid, k << 1);
    build(mid + 1, r, k << 1 | 1);
    maintain(k);
}
void change(int k)
{
    swap(tree[k].c7, tree[k].c4);
    swap(tree[k].up, tree[k].down);
}
void pushdown(int k)
{
    if (tree[k].rev)
    {
        tree[k << 1].rev ^= 1;
        tree[k << 1 | 1].rev ^= 1;
        change(k << 1);
        change(k << 1 | 1);
        tree[k].rev = 0;
    }
}
void reverse(int l, int r, int k)
{
    if (tree[k].left == l && tree[k].right == r)
    {
        change(k);
        tree[k].rev ^= 1;
        return;
    }
    pushdown(k);
    int mid = (tree[k].left + tree[k].right) >> 1;
    if (l > mid)
    {
        reverse(l, r, k << 1 | 1);
    }
    else if (r <= mid)
    {
        reverse(l, r, k << 1);
    }
    else
    {
        reverse(l, mid, k << 1);
        reverse(mid + 1, r, k << 1 | 1);
    }
    maintain(k);
}
int main()
{
    int n, m;
    while (~scanf("%d%d", &n, &m))
    {
        scanf("%s", s + 1);
        build(1, n, 1);
        for (int i = 0; i < m; i++)
        {
            char s[10];
            scanf("%s", s);
            if (s[0] == 'c')
            {
                printf("%d\n", tree[1].up);
            }
            else
            {
                int l, r;
                scanf("%d%d", &l, &r);
                reverse(l, r, 1);
            }
        }
    }
}