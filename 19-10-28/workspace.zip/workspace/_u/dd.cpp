#include "bits/stdc++.h"
using namespace std;
int main()
{
    ifstream in("out.txt");
    string s;
    while (getline(in, s))
    {
        stringstream ss;
        ss << "wget -U \"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36\" \"" << s << "\"";
        system(ss.str().c_str());
    }
}