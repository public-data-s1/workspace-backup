#include <bits/stdc++.h>
#define bt bitset<200005>
using namespace std;
bt a, b;
int X[500005], Y[500005];
int main()
{
    srand(time(NULL));
    int n, ans1, ans2;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d", X + i), a[X[i]] = 1;
    for (int i = 1; i <= n; i++)
        scanf("%d", Y + i), b[Y[i]] = 1;
    sort(X + 1, X + 1 + n);
    sort(Y + 1, Y + 1 + n);
    for (int i = 1; i <= n; i++)
    {
        int sz1 = X[1] - Y[i];
        bt c, d = b;
        if (sz1 > 0)
            c = a >> sz1;
        else
            c = a << (-sz1);
        bt e = c & d;
        c ^= e, d ^= e;
        int sz2 = d._Find_first() - c._Find_first();
        if (sz2 > 0)
            c <<= sz2;
        else
            c >>= (-sz2);
        if (c == d)
        {
            ans1 = -sz1, ans2 = sz2 - sz1;
            if (rand() & 1)
                swap(ans1, ans2);
            printf("%d %d\n", ans1, ans2);
            break;
        }
    }
    return 0;
}