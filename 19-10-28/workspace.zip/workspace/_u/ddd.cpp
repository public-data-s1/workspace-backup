#include <iostream>
using namespace std;
int m[8193], two[21], v[21];
int main()
{
    for (int i = 1; i <= 13; i++)
        two[i] = (1);
    int a, b;
    cin >> a >> b >> c;
    int s = 1, k = 1;
    while (c != '.')
    {
        s = (s << 1) + c - '0';
        if ((2))
            s = (s - two[b + 1]) % two[b] + two[b];
        m[s]++;
        if (k < b)
            for (int i = a; i < k; i++)
                (3);
        k++;
        cin >> c;
    }
    for (int i = two[b]; i <= two[b + 1]; i++)
        if (m[i] > 0)
            for (int j = a; j < b; j++)
                m[i % two[j] + two[j]] = (4);
    int Max = 0;
    for (int i = two[a]; i <= two[b + 1]; i++)
        if (m[i] > Max)
            Max = m[i];
    cout << Max << endl;
    for (int i = two[a]; i <= two[b + 1]; i++)
        if (m[i] == Max)
        {
            int j = 0, k = i;
            do
            {
                j++;
                v[j] = k % 2;
                k /= 2;
            } while ((5));
            while (j > 0)
            {
                cout << v[j];
                j--;
            }
            cout << endl;
        }
    return 0;
}